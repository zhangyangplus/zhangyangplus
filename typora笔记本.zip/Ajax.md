# Ajax

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #result {
            width: 200px;
            height: 100px;
            border: 1px solid red;
        }
    </style>
</head>

<body>
    <button>点击发送</button>
    <div id="result"></div>
    <script>
        const btn = document.getElementsByTagName('button')[0];
        btn.onclick = function () {
            const xhr = new XMLHttpRequest();
            const result = document.getElementById('result');
            //初始化，发送请求方法和url
            xhr.open('GET', 'http://127.0.0.1:8000/server');
            //发送
            xhr.send();
            //事件绑定，处理服务器返回的结果0:未初始化
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if (xhr.status >= 200 && xhr.status <= 300) {
                        //console.log(xhr.status)//状态码
                       // console.log(xhr.statusText)//响应字符串
                        //console.log(xhr.getAllResponseHeaders)//所有响应头
                        //console.log(xhr.response)//响应体
                        result.innerText=xhr.response
                    }
                }
            }
        }
    </script>
</body>

</html>

*const* { response } = require('express');

*const* express=require('express');

*const* { request } = require('http');

*//创建应用对象*

*const* app=express();

*//创建路由规则*

app.get('/',(*request*,*response*)=>{

response.send('hello')

});

*//监听端口启动服务*

app.listen(8000,()=>{

console.log("服务已经启动,8000");

})

## 向服务器发送请求

| onreadystatechange | 定义当 readyState 属性发生变化时被调用的函数                 |
| ------------------ | ------------------------------------------------------------ |
| readyState         | 保存 XMLHttpRequest 的状态。0：请求未初始化1：服务器连接已建立2：请求已收到3：正在处理请求4：请求已完成且响应已就绪 |
| responseText       | 以字符串返回响应数据                                         |
| responseXML        | 以 XML 数据返回响应数据                                      |
| status             | 返回请求的状态号200: "OK"403: "Forbidden"404: "Not Found"如需完整列表请访问 [Http 消息参考手册](https://www.w3school.com.cn/tags/html_ref_httpmessages.asp) |
| statusText         | 返回状态文本（比如 "OK" 或 "Not Found"）                     |

## GET 还是 POST？

GET 比 POST 更简单更快，可用于大多数情况下。

不过，请在以下情况始终使用 POST：

- 缓存文件不是选项（更新服务器上的文件或数据库）
- 向服务器发送大量数据（POST 无大小限制）
- 发送用户输入（可包含未知字符），POST 比 GET 更强大更安全

如需像 HTML 表单那样 POST 数据，请通过 `setRequestHeader()` 添加一个 HTTP 头部。请在 `send()` 方法中规定您需要发送的数据：

### 实例

```
xhttp.open("POST", "ajax_test.asp", true);
xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
xhttp.send("fname=Bill&lname=Gates");
```

## 异步 - true 还是 false？

如需异步发送请求，`open()` 方法的 *async* 参数必须设置为 `true`：

```
xhttp.open("GET", "ajax_test.asp", true);
```

发送异步请求对 web 开发人员来说是一个巨大的进步。服务器上执行的许多任务都非常耗时。在 AJAX 之前，此操作可能会导致应用程序挂起或停止。

通过异步发送，JavaScript 不必等待服务器响应，而是可以：

- 在等待服务器响应时执行其他脚本

- 当响应就绪时处理响应

  ## onreadystatechange 属性

  `readyState` 属性存留 XMLHttpRequest 的状态。

  `onreadystatechange` 属性定义当 readyState 发生变化时执行的函数。

  `status` 属性和 `statusText` 属性存有 XMLHttpRequest 对象的状态。

  ## 使用回调函数

  回调函数是一种作为参数被传递到另一个函数的函数。

  如果您的网站中有多个 AJAX 任务，那么您应该创建一个执行 XMLHttpRequest 对象的函数，以及一个供每个 AJAX 任务的回调函数。

  该函数应当包含 URL 以及当响应就绪时调用的函数。

  ### 实例

  ```
  loadDoc("url-1", myFunction1);
  
  loadDoc("url-2", myFunction2);
  
  function loadDoc(url, cFunction) {
    var xhttp;
    xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        cFunction(this);
      }
    };
    xhttp.open("GET", url, true);
    xhttp.send();
  }
  
  function myFunction1(xhttp) {
    // 行动在这里
   } 
  function myFunction2(xhttp) {
    // 行动在这里
   } 
  ```

## 服务器响应属性

| 属性         | 描述                        |
| :----------- | :-------------------------- |
| responseText | 获取字符串形式的响应数据    |
| responseXML  | 获取 XML 数据形式的响应数据 |

## 服务器响应方法

| 方法                    | 描述                       |
| :---------------------- | -------------------------- |
| getResponseHeader()     | 从服务器返回特定的头部信息 |
| getAllResponseHeaders() | 从服务器返回所有头部信息   |