# Mybatis

## 1.三层架构

mvc:web开发中，m:数据 v:视图 v:视图 c:控制器

- 控制器:接受请求，调用service对象，显示请求的处理结果，当期使用的servlet
- 视图：jsp、HTML、css、js,把m中的数据显示出来
- 数据:mysql,文件,网络

mvc作用:

- 实现解耦合
- 让mvc各司其职
- 使系统的扩展性更好，容易维护

三层架构

1. 界面层(视图):接受用户的请求，调用service，显示请求的处理结果，jsp，html,servlet等，跟用户交互,对应的包controller
2. 业务逻辑层:处理业务逻辑，使用算法数据的，把数据返回给界面层，对应的service包，和包中的很多的xxxservice类，例如:StudentService....
3. 持久层(数据访问层):访问数据库，或者读取文件、访问网络，获取数据，对应的包是dao

## 2.三层架构请求的处理流程

用户发起请求----->界面层---->业务逻辑层----->持久层------>数据库（mysql）

### 三层架构的模式和框架

1)界面层---springmvc框架

2)业务层---Spring框架

3）持久层---MyBatis框架

### Mybatis框架

是一个优秀的基于Java的持久层框架，内部封装了jdbc,开发者只需要关注sql语句本身，而不需要处理加载驱动、创建连接、创建statement、关闭数据连接

### Spring框架

为了解决软件开发的复杂性而创建的，Spring使用的基本的JavaBean来完成以前非常复杂的企业级开发，Spring解决了业务对象，功能模块

### SpringMVC

属于SpringFrameWork3.0版本的一个模块，为Spring框架提供了构建Web应用程序的能力

## 第一个例子

- 创建student表(id,name,email,age)
- 新建maven项目
- 修改pom文件
  - 加入依赖，MySQL驱动，junit
  - 在<build>加入资源插件

- 创建实体类Student，定义属性，属性名和列名保持一致

- 创建Dao接口，定义操作数据库的方法

- 创建xml文件(mapper文件)，写sql 语句

  - mybatis框架推是把sql语句和Java代码分开

  - mapper文件:定义和dao接口在同一目录，一个表一个mapper文件

- 创建mybatis配置文件(有一个放在resources目录下)
  - 定义创建连接实例的数据源对象(DataSource)对象
  - 指定其他mapper文件的位置

- 创建测试内容

  使用main方法、junit方法测试