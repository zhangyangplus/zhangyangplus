# AWT

```java
package com.zyStu.cal;

import javax.swing.*;
import java.awt.*;

public class DrawCircle extends JFrame {
    //定义面板
    private MyPanel mp=null;
    public static void main(String[] args) {
        new DrawCircle();
    }
    public DrawCircle(){
        //初始化面板
        mp=new MyPanel();
        //把面板放入到窗口
        this.add(mp);
        //设置窗口大小
        this.setSize(600,500);
        //可视
        this.setVisible(true);
        //点击窗口的小叉，程序完全退出
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
//定义面板
class MyPanel extends Panel{
    @Override
    public void paint(Graphics g) {
        g.setColor(Color.red);
        g.fillRect(10,10,20,20);
    }
}
```