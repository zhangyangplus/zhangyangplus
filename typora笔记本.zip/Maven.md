# Maven

```java
//tomcat7maven配置
<build>
    <finalName>zhangjava</finalName>
    <plugins>
  <plugin>
    <!-- https://mvnrepository.com/artifact/org.apache.tomcat.maven/tomcat7-maven-plugin -->
      <groupId>org.apache.tomcat.maven</groupId>
      <artifactId>tomcat7-maven-plugin</artifactId>
      <version>2.1</version>
    <configuration>
<!--      设置端口号-->
      <port>80</port>
<!--      虚拟路径-->
      <path></path>
    </configuration>
  </plugin>
    </plugins>
  </build>
```

## Maven

1. maven可以管理jar文件
2. 管理下载jar和他的文档，源代码
3. 管理jar直接的依赖，a.jar需要b.jar maven会自动下载b.jar
4. 帮你编译程序,把jar编译成class
5. 帮你测试你的代码是否正确
6. 帮你打包文件，形成jar文件，或者war文件
7. 帮你部署项目

项目的构建（面向过程）

1. 完成项目代码的编译、测试、运行、打包、部署等等
   - 清理：把之前项目编译的东西删掉，为新的编译代码准备
   - 编译：把源代码编译为可执行代码（批量）
   - 把成千上百文件编译成class Javac只编译一个
   - 测试：maven可执行测试程序代码，来验证功能是否正确，可测试很多
   - 报告：生成测试结果文件
   - 打包：把项目所有class文件配置文件等所有资源放到一个亚索文件中，压缩文件就是结果文件
   - 安装：把jar war文件安装到本机仓库
   - 部署：把程序安装好可以执行

maven的核心概念

- [ ] pom:项目对象模型，把项目当作模型，控制maven构建项目的过程，管理jar依赖
- [ ] 坐标：用来标识资源的
- [ ] 依赖管理：管理项目可以使用jar文件
- [ ] 仓库管理：资源存放位置
- [ ] 生命周期：构建项目的过程
- [ ] 插件：
- [ ] 继承：
- [ ] 聚合