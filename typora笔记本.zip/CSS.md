# 1.CSS

x package com.zyStu.cal;​import javax.swing.*;import java.awt.*;​public class DrawCircle extends JFrame {    //定义面板    private MyPanel mp=null;    public static void main(String[] args) {        new DrawCircle();    }    public DrawCircle(){        //初始化面板        mp=new MyPanel();        //把面板放入到窗口        this.add(mp);        //设置窗口大小        this.setSize(600,500);        //可视        this.setVisible(true);        //点击窗口的小叉，程序完全退出        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    }}//定义面板class MyPanel extends Panel{    @Override    public void paint(Graphics g) {        g.setColor(Color.red);        g.fillRect(10,10,20,20);    }}java

div{

​    height: 20px;

​    width: 400px;

​    border-style:dotted solid double dashed;

  }

![image-20220815174740445](C:\Users\ZY\AppData\Roaming\Typora\typora-user-images\image-20220815174740445.png)

# 2.a标签

target 用于指定页面链接打开方式。其中_self为默认值，__blank为在新窗口

# 3.lable

lable for中的值要跟id里面的值一样

下拉表单元素

<select/>shang<option/>

文本域

<textarea rows=5/>显示5行

# 4.字体

font-family 字体设置

font-weight 字体样式（100-900）

font-style: italic; 斜体 normal 默认的 。斜体也可使用<em>西克后</em> 更改设置为normal

字体的复合属性

font:font-style font-weight font-size/line-height font-family; 🆘按照这个顺序 保留size family 否则不起作用

装饰文本

text-decoration(none {underline 下划线 }{overline 上划线}{through 删除线})

text-indent:20px 缩进 {em 相对于当前元素}

图片水平对齐，父标签添加水平居中

# 5.选择器与图片

| 说明            | 符号            | 备注                                                         | 注意n        |
| --------------- | --------------- | ------------------------------------------------------------ | ------------ |
| 背景平铺        |                 | no-repeat repeat-x repeat-y                                  |              |
| 父子级关系的    | >               | （元素创建）                                                 |              |
| 兄弟关系        | +               | （元素创建）                                                 |              |
| 父子级          |                 | （css空格）                                                  |              |
| css子元素选择器 | >               | （只选择后面的一个元素）                                     |              |
| 并集选择器      | ，              | div,a                                                        |              |
| 伪类            | :hover          |                                                              |              |
| 动画            | transition: 3s; | a:link (选择所有已访问的)visited(选则自己已访问的)active鼠标按下未弹起 focuse(选取获得焦点的表单元素) | 按照lvha顺序 |
| back-position   | x,y             | top,center,botton,left,right                                 |              |
| 行元素—>        | display:block   | 块级元素——> display:inline   行类元素                        |              |

## 5.1背景图片固定

| 属性                  | 说明                                               | 用法                                  | 值           |
| --------------------- | -------------------------------------------------- | ------------------------------------- | ------------ |
| background-attachment | 属性设置背景图片是否固定或者随着页面的其余部分滚动 | 后期可以制作视察滚动效果              | scroll,fixed |
| background            | 顺序随意                                           | 复合写法 （颜色 地址 平铺 滚动 位置） |              |
| background rgba       | 设置半透明                                         |                                       |              |

### 5.1.1行高的继承

font:12px/1.5 当前行高的1.5倍

层叠性:就近原则

| 选择器               | 选择器权重 |
| -------------------- | ---------- |
| 继承 或者*           | 0，0，0，0 |
| 元素选择器           | 0，0，0，1 |
| 类选择器，伪类选择器 | 0，0，1，0 |
| ID选择器             | 0，1，0，0 |
| 行内样式 style       | 1,0,0,0    |
| !import 重要的       | 无穷大     |

网页布局过程

1.准备好相关元素 2.设置CSS样式，摆到相应位置3.往盒子中装内容 核心：在网页中摆盒子

| 元素名  | 样式                                            |                                                     |
| ------- | ----------------------------------------------- | --------------------------------------------------- |
| border  | border-width: 5px;                              |                                                     |
|         | border-style solid  dashed(虚线) dotted（点线） |                                                     |
| padding | 影响盒子实际大小                                | 如果没有指定盒子的width/height，padding是不会撑开的 |
| margin  | 外边距可以让块级盒子居中                        | 条件：盒子必须指定width 盒子左右外边距为 auto       |

行内元素水平居中的方法：行内元素或者行内块元素水平居中给其父元素添加text-align:center

盒子塌陷问题：给父元素设置边框 给父元素设置内边距 父元素添加overflow：hidden

清除内外边距

padding 0 margin 0

list-style: none; 去掉小li中的圆点

### 5.1.2盒子模型

盒子阴影：box-shadow:h-shadow(水平) v-shadow(垂直) blur(可选,模糊距离) spread(可选 阴影尺寸) color （可选，阴影颜色）inset(将外部阴影改为内部阴影)

文字阴影 前三个跟盒子一样，最后一个是color

盒子排列纵向排列：标准流    横向:浮动流

浮动特性：脱离标准流 一行内显示并且元素顶部对齐  具有行内块元素的特性

脱离标准普通流的控制移动到指定位置，俗称脱标

浮动的盒子不在保留原先的位置(浮动的盒子不会有外边距合并的问题)

li的最后一个有宽度

浮动只会影响后面的标准流

清楚浮动  clear:left right both 方法:父级添加overflow 父级添加after伪元素 父级添加双伪元素 额外标签法（后面添加空元素）.overflow(防止外边距合并)

```css
//额外标签法
.clear{
				clear: both;
			}

```

![image-20220817234952062](C:\Users\ZY\AppData\Roaming\Typora\typora-user-images\image-20220817234952062.png)

：after添加伪元素 为父元素添加

```css
.fa:after{
				content: "";
				display: block;
				height: 0;
				clear: both;
				visibility: hidden;
			}


```

双伪元素清除浮动

```css
.fa:before,
		.fa:after{
			content: "";
			display: table;
		}
		.fa:after{
			clear: both;
		}
```

# 6.定位

| postion                           |          |                                                              | 使用场景 |
| --------------------------------- | -------- | ------------------------------------------------------------ | -------- |
| relative                          | 相对定位 | 以自己原来位置为准，设置偏移量，    位置会保留               |          |
| absolute                          | 绝对定位 | 相对于祖先元素（父元素要开启定位，不然以浏览器为对象）如果祖先元素有定位，则以最近一级的有定位祖先元素为参考点 |          |
| 绝对定位脱离标准流,原来位置不保留 |          |                                                              |          |
| fixed                             | 固定定位 |                                                              |          |
| 叠放次序问题                      |          |                                                              |          |
| 粘性定位                          |          | 以浏览器可视窗口为参照，占有原先的位置必须添加top left right其中一个 |          |
| 设置定位元素居中                  |          |                                                              |          |

行内元素添加定位 可直接设置宽高 块级元素加固定定位或者绝对定位，如果不给宽高，则宽度为内容的宽度

浮动元素只会压住它下main标准流的盒子，但是不会压住下面标准流盒子里面的文字（图片） 原因：设计的初衷是文字环绕效果

绝对定位和固定定位可以做到

去除表格双线：border-collapse: collapse

```scc
display:none 隐藏对象 不在占有原来的位置  （人生的一大悲哀）
display:block 显示元素
visibility:visible 元素可见 
visibility:hidden 隐藏 位置保留
overflow 溢出部分操作
overflow:scroll 溢出滚动条 auto 需要时候添加滚动条
```

# 7.精灵图和CSS3的新特性

 

#鼠标样式

```css
cursor: pointer小手  default 小白，默认 move 移动 text 文本 not-allowed 禁止
textarea标签，能随意拖动大小，会影响其他盒子大小，去掉的方法
resize: none
vertical-align：baseline 默认，元素放在父元素的基线上，top把元素的顶端与最高元素的顶端对齐
middle 把此元素放在父元素的中部 bottom把元素的顶端与行中最低元素的顶端对齐  只针对行内或者行内块
```

图片空白空隙

```css
方案一:给图片添加 vertical-align:middle|top|bottom 提倡使用
方案二: display:block
```

单行文本省略

```css
1.先强制一行内希纳是文本
white-space:nowrap(默认normal自动换行)
2.超出部分隐藏
overflow:hidden;
3.文字用省略号替代超出部分
text-overflow:ellipsis;
```

多行文本溢出省略号

```css
overflow:hidden;
text-overflow:ellipsis;
display:-webkit-box;
限制一个块元素显示的文本行数
-webkit-line-calmp:2;
设置或检索伸缩盒子对象的子元素的排类方式
-webkit-box-orient:vertical;
```

常见的布局技巧

```css
1.margin负值盒子边框2倍宽
文字环绕
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<style>
			.box{
				width: 300px;
				height: 70px;
				margin: 0 auto;
				background-color: pink;
			}
			.pic{
				float: left;
				width: 120px;
				height: 70px;
				margin: 0 auto;
				background-color: pink;
			}
			.pic img{
				width: 100%;
			}
		</style>
	</head>
	<body>
		<div class="box">
			<div class="pic">
				<img  src="../PINK/images/img.png ">
				</div>
			<p> 世界阿是嘎十九大精神第八届花园酒店国际奥赛的改变哈桑
			 </p>
		</div>
	</body>
</html>
```

属性选择器

```css
div[class^=ico] 选择属性class 以ico开头的
section[class$=data]  选择属性以data结尾的
section[class*=icon] 只要含有icon 的全部渲染
注意：类选择器、属性选择器、伪类选择器、权重为10.
```

结构伪类选择器

```css
E:first-child 匹配父元素的第一个子元素E
E:last-child 匹配父元素最后一个E元素
E:nth-child(n) 匹配父元素中的第n个子元素E
E:first-of-type:指定类型E的第一个
E:last-of-type:指定E的类型最后一个
E:nth-of-type(n):指定类型E的第n个
ul li:first-child 选择ul中第一个孩子为小li的
/* 表格的隔行变色 */
ul :nth-child(even) 偶数行
ul :nth-child(odd) 奇数行
ol li:nth-child(n) 选择所有的孩子 2n偶数 2n+1 奇数 5n 5的倍数 n+5 从第5个开始 -n+5 前5个
nth-child 会把所有的孩子都牌号，执行时候先看nth-child(1) 之后看前面div 结果是p 所以匹配不上
```

```html
nth-child 会把所有的孩子都牌号，执行时候先看nth-child(1) 之后看前面div 结果是p 所以匹配不上
section div:nth-child(1){
				background-color: red;
			}
<section>
			<p>光头强</p>
			<div>熊大</div>
			<div>熊二</div>
		</section>
section div:nth-of-type(1){
				background-color: red;
			}
会把指定元素的排上序号，所有能匹配上
```

为元素选择器

| 选择符   | 简介                                       |      |      |
| -------- | ------------------------------------------ | ---- | ---- |
| ::before | 在元素的内部的前面插入内容 content是必须的 |      |      |
| ::after  | 在元素内部的后面插入内容content是必须的    |      |      |

伪元素清除浮动

```css
.clearfix:after{
    content:"";
    display:block;
    height:0;
    clear:both;
    visibility:hidden;
}
或者
.clearfix:before,.clearfix:after{
    content:"";
    display:table;  //在一行上
}
.clearfix:after{
    clear:both;
}
```

```css
//以前的盒子加边框会增大盒子，加内边距还会增大，解决办法就是在原来的盒子减去
//css3 通过box-sizing 来指定盒子模型，有2个值：即可指定为content-box、border-box,这样我们计算盒子大小的方式就发生了变化
1.box-sizing:content-box 盒子大小为width+padding+border（以前默认的）
2.box-sizing:border-box 盒子大小为width（前提padding和border不会超过width宽度）
```

图片便模糊和width:calc函数

```css
filter:blur(5px);blur模糊处理，值越大越模糊
width:calc(100%-80px) 父盒子100%总是比子盒子宽80px 可以进行加减乘除运算 注意空格隔开
```

过度

```css
transition:要过度的属性 花费时间 运动曲线 何时开始;
1.属性:想要变化的css属性，宽高背景色 内外边距，所有属性变化过度，写all就可以
2.花费时间:s
3.运动曲线:默认是ease逐渐慢下来  liner 匀速 ease-in 加速  ease-out：减速  ease-in-out: 先加速后减速
4.何时开始:单位s可以设置延迟触发时间
```

网站的favicon图标

1.把图片切成png图片

2.把png图片转换成ico图标，这需要借助第三方转换网站，例如比特虫:http://www.bitbug.net/

3.<link rel="shortcut icon" href="favicon.ico" type=""> 位置
