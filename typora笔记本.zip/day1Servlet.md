# day1Servlet

# 1.Servlet配置

```html
<web-app>
  <display-name>Archetype Created Web Application</display-name>
<servlet>
  <servlet-name>Servlet01</servlet-name>
  <servlet-class>com.zyStu.testFile.Servlet01.Servlet01</servlet-class>
  
</servlet>
  <servlet-mapping>
    <servlet-name>Servlet01</servlet-name>
    <url-pattern>/hello</url-pattern>
  </servlet-mapping>
</web-app>
```

# 2.Servlet生命周期

```java
public Servlet01() {
    System.out.println("构造器方法");
}

public void init(ServletConfig servletConfig) throws ServletException {
    System.out.println("init");
}

public ServletConfig getServletConfig() {
    System.out.println("getServletConfig");
    return null;
}

public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
    System.out.println(" service 被访问了");
}

public String getServletInfo() {
    System.out.println("getServletInfo");
    return null;
}

public void destroy() {
    System.out.println("destroy被销毁");
}
```

# 3.Session

会话是指一个终端用户与交互系统进行通讯的过程。

比如从输入账户密码进入操作系统到退出操作系统就是一个会话过程。会话较多用于网络上，TCP的三次握手就创建了一个会话，TCP关闭连接就是关闭会话。

Session代表服务器与浏览器的一次会话过程，这个过程是连续的，也可以时断时续的。在Servlet中，当JSP页面没有显式禁止session的时候，在打开浏览器第一次请求该jsp的时候，服务器会自动为其创建一个session，并赋予其一个sessionID，发送给客户端的浏览器。

以后客户端接着请求本应用中其他资源的时候，会自动在请求头上添加：（Cookie:SESSIONID=客户端第一次拿到的session ID）。这样，服务器端在接到请求时候，就会收到session ID，并根据ID在内存中找到之前创建的session对象。

# 4.servlet监听器

概述：

Listener是Servlet的监听器，它可以监听客户端的请求、服务端的操作等。通过监听器，可以自动激发一些操作，比如监听在线的用户的数量。监听的事件源分别为SerlvetConext,HttpSession和ServletRequest这三个域对象。

实现：

不同功能的Listener 需要实现不同的 Listener 接口，一个Listener也可以实现多个接口，这样就可以多种功能的监听器一起工作。

2、8种监听器可以分为三类：

1）监听 Session、request、context 的创建于销毁，分别为

HttpSessionLister、ServletContextListener、ServletRequestListener

2）监听对象属性变化，分别为：

HttpSessionAttributeLister、ServletContextAttributeListener、ServletRequestAttributeListener

3）监听Session 内的对象，分别为HttpSessionBindingListener 和 HttpSessionActivationListener。与上面六类不同，这两类 Listener 监听的是Session 内的对象，而非 Session 本身，不需要在 web.xml中配置。

2、实现web.xml的Listener配置。

1）<listener>标签与 <listener-class>

xxxxxxxxxx //tomcat内置线程池,数据库关闭还得移除键值对local.remove();java

# 5.Session的方法

```Java
//获取session
HttpSession session = req.getSession();
//获取session的会话标识
String id = session.getId();
System.out.println(id);
//获取session的创建时间
long creationTime = session.getCreationTime();
System.out.println(creationTime);
//获取最后一访问时间
System.out.println(session.getLastAccessedTime());
//判断session是否是新的对象
boolean aNew = session.isNew();
System.out.println(aNew);
```

# 6.Session域对象

Session用来标识一次会话，在一次会话中数据可以是共享的，这时session作为域对象存在，可以通过setAttribute(name,value)向域对象中添加数据，通过getAttribute(name)从域对象中获取数据，通过removeAttrubutr(name)从与对此项中移除数据



```Java
 //获取session
        HttpSession session = req.getSession();
        session.setAttribute("uname","session域对象pwd");
        session.setAttribute("admin","session域对象123434");
        req.setAttribute("name","request域对象");
        //请求转发
        req.getRequestDispatcher("index.jsp").forward(req,resp);

```

# 7.Jquery

```javascript
var tr = $("<tr align=\"center\" class=\"d\">");
//2.创建多个列
var tdCheck = $("<td><input type=\"checkbox\" value=\""+book.id+"\" class=\"ck\" checked /></td>");
var tdName = $("<td>"+book.name+"</td>");
```

javaEE8.0被捐了 以后叫jakartaEE

serverlet无参构造方法是在对象第一次创建的时候执行，并且只执行一次，init方法也是在对象第一次创建的时候只执行一次

那么这个无参构造方法可以代替init方法吗？（不能，编写构造方法很容易让无参构造方法消失，这个操作可能会使Servlet对象无法实例化，所以init方法是有存在必要的）

编写抽象类实现servlet接口，抽象方法service这个类就是适配器，以后编写的所有servlet继承这个就行。（适配器模式）

init中servletconfig是tomcat服务器创建传给init方法

```java
public class Tomcat{
    Class class=Class.forName("com.LoginlinServlet");
    
}
```

模板设计模式

加入init只执行一次而且无法重写这时候可以在声明一个init然后在init中调用

transient修饰不参与序列化

序列化版本号：区分类

1. servletConfig是什么？是接口，


2.谁创建的？（web服务器）

3.servlet是tomcat创建的

servlet与servletConfig一一对应(同时创建的）

servletConfig是servlet的配置信息对象

3.servletConfig包含什么信息呢(web.xml文件中配置信息tomcat解析配置文件自动包装到servletConfig对象)

```xml
<servlet-mapping>
        <servlet-name>configTestServlet</servlet-name>
        <url-pattern>/con</url-pattern>
    </servlet-mapping>
```

```java

```

4.servletConfig接口

//主要方法

```java
public String getInitParameter(String name);//获取value
public Enumeration<String> getInitparamterNames();//获取所有初始化参数name
public ServletContext getservletContext();//
public String getServletName();
//以上方法都可以使用this调用
```

Servlet中的<servlet/>信息被tomcat自动封装到servletConfig中

5.ServletContext是谁实现的（web服务器）是谁创建的，在什么时候创建的（web服务器启动时创建的）

5.1**对于一个webapp来说，servlet只有一个，在服务器关闭时候销毁，servletContext是servlet的上下文对象，50个学生，每一个都是Servlet，这50个学生都在同一个教室中，那么教室相当与ServletContext对象，放在ServletContext对象中的数据，所有Servlet一定共享，所以ServletContext是应用级对象，一个webapp只有一个ServletContext  ServletContext是一个接口，tomcat对其进行实现，创建也是他完成的 tomcat正在部署到部署成功就是在构建ServletContext对象**

# 8.servlet接口中常用方法

```Java
public String getInitparamter(String name);//初始化name获取value
public Enumeration<String> getInitParameterNames();//获取所有初始化name

```

```xml
//获取配置信息，全局
//如果你的配置信息只想给某一个Servlet作为参考，那么就要配置到servlet标签即可，使用ServletConfig获取
<context-param>
        <param-name>pageSize</param-name>
        <param-value>10</param-value>
    </context-param>
    <context-param>
        <param-name>startIndex</param-name>
        <param-value>0</param-value>
    </context-param>
```

```Java
//获取应用根路径，有些地方需要，动态获取，不要将根路径写死，应用最终部署，起什么名字不定的
String contextpath=application.getContextPath()
//获取文件的绝对路径（真实路径）
String getRealPath(String var1);
```

```java
//通过servletContext方法记录日志
public void log(String msg);
public void log(String msg,Throwable t);
```

```java
//servletContext对象还有另一个名字：应用域
//如果所有用户共享一份数据，这个数据很少被修改，并且数据量小，可以将这些数据放到ServletContext
//为什么是所有用户共享?因为servletContext只有一个，共享数据才有意义
//为什么数据量要小?数据量太大占用堆内存，并且这个对象生命周期长，服务器关闭的时候，这个对象才会被销毁（你不关，我不死）大数据量会影响服务器的性能
//为什么这些共享数据很少的修改，或者说几乎不修改？
//所有用户共享数据，涉及到修改操作，必然存在线程并发带来的安全问题，所以ServletContext对象中的数据一般都是只读的
//数据量少，所有用户共享，又不修改，这样的数据放到ServletContext这个应用域当中，会大大提升效率，因为应用域相当与一个缓存，放到缓存中的数据，下次再用的时候，不需要从数据库中再次获取，大大提升执行效率
//存
public void setAttribute(String name,Obj value);
//取
public Object getAttribute(String name);
//删
public void removeAttribute(String name);
```

缓存机制

1. 堆内存当中的字符串常量池

   "abc" 先在字符串常量池中查找，如果有，直接拿来用，如果没有则新建，然后放回字符串常量池

2. 堆内存当中的整数型常量池

   [-128~127] 一共256个Integer类型的引用,放在整数型常量池中,没有超出这个范围的话,直接从常量池中取

​			3.连接池

​				Java语言连接数据库的连接对象：java.sql.connection

​				JVM是进程，Mysql也是，进程与进程之间建立连接，打开通道很费劲，很耗资源，可以提前创建号N个连接，将				连接对象放到一个集合中，我们把这个放到Connection对象的集合称为连接池，每一次用户连接的时候不需要再				新建连接对象，省去了新建的环节，直接从连接池中获取连接对象，大大提升访问效率

​			4.线程池

​			Tomcat服务器发送一次请求，就新建一个对象吗?

​			不是，实际上Tomcat服务器启动时，会创建N个线程Thread对象，然后将线程对象放到集合中，称为线程池，			用户发送请求过来之后，需要有一个对应的线程来处理这个请求，这时候线程对象就会直接从线程池中拿，效率高			

​			5.redis

​				NoSql数据库，非关系型数据库，缓存数据库

​			6.向ServletContext中存数据，也是将数据放到缓存cache中

# 9.HTTP协议

- 什么是协议
- 什么是Http协议(w3c制定的一种超文本传输协议)(通信协议)
- Http协议包含请求协议和响应协议
  - 请求协议：浏览器向web服务器发送数据的时候，这个发送的数据需要遵循一套标准，这套标准中规定了发送的数据具体格式

- HTTP请求协议四部分

  - 请求行
  - 请求头
  - 空白行
  - 请求体

- HTTP请求协议的报文GET请求

  ```html
  GET /servlet05/getServlet?username=super&userpwd=3434 HTTP/1.1 请求行
  Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
  Accept-Encoding: gzip, deflate, br
  Accept-Language: zh-CN,zh;q=0.9
  Connection: keep-alive
  Cookie: NMTID=00OOC654x1jzkjfVUWxh67VFHsEwGoAAAGCHn67cQ; Idea-1f87ef0d=d7682971-76f0-4fa8-8974-a14d51d33555; Idea-1f87f68e=e36daeaf-e2ae-47ea-86f4-5a6a1156c75d
  Host: localhost:8888
  Referer: http://localhost:8888/servlet05/
  Sec-Fetch-Dest: document
  Sec-Fetch-Mode: navigate
  Sec-Fetch-Site: same-origin
  Sec-Fetch-User: ?1
  Upgrade-Insecure-Requests: 1
  User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36
  sec-ch-ua: "Chromium";v="104", " Not A;Brand";v="99", "Google Chrome";v="104"
  sec-ch-ua-mobile: ?0
  sec-ch-ua-platform: "Windows"
  							(空白行)
  ```

  HTTP请求协议的报文POST请求

  ```html
  POST /servlet05/postServlet HTTP/1.1
  Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
  Accept-Encoding: gzip, deflate, br
  Accept-Language: zh-CN,zh;q=0.9
  Cache-Control: max-age=0
  Connection: keep-alive
  Content-Length: 49
  Content-Type: application/x-www-form-urlencoded
  Cookie: NMTID=00OOC654x1jzkjfVUWxh67VFHsEwGoAAAGCHn67cQ; Idea-1f87ef0d=d7682971-76f0-4fa8-8974-a14d51d33555; Idea-1f87f68e=e36daeaf-e2ae-47ea-86f4-5a6a1156c75d
  Host: localhost:8888
  Origin: http://localhost:8888
  Referer: http://localhost:8888/servlet05/
  Sec-Fetch-Dest: document
  Sec-Fetch-Mode: navigate
  Sec-Fetch-Site: same-origin
  Sec-Fetch-User: ?1
  Upgrade-Insecure-Requests: 1
  User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36
  sec-ch-ua: "Chromium";v="104", " Not A;Brand";v="99", "Google Chrome";v="104"
  sec-ch-ua-mobile: ?0
  sec-ch-ua-platform: "Windows"
  //
  formdata
  username: 李思思
  userpwd: 3434
  ```

  

- HTTP响应协议

  - 状态行
  - 响应头
  - 空白行(分割作用)
  - 响应体

- HTTP响应协议报文（GET）

  ```html
  HTTP/1.1 200（状态行）
  Content-Type: text/html;charset=ISO-8859-1（响应头）
  Content-Length: 97（响应头）
  Date: Mon, 22 Aug 2022 08:43:43 GMT（响应头）
  Keep-Alive: timeout=20（响应头）
  Connection: keep-alive（响应头）
                         （空白行）
  <!DOCTYPE html><html><head><title>from get servlet</title></head><body><h1>GET</h1></body></html>（响应体）
  ```

  GET请求和POST请求的区别？

  - get请求发送数据的时候，数据会挂在URI的后面,添加问号后面拼接数据，导致发送的数据显示在地址栏上(get请求在请求行上发数据)
  - POST在请求体上发送数据，地址栏上看不到
  - 不管是get还是post请求，发送请求数据的格式是相同的  
  - get请求只能发送普通的字符串，并且发送的长度有限，不用浏览器限制不同          
  - get请求无法发送大数据量
  - post请求可以发送任何类型的数据，包括普通字符串，流媒体等信息           
  - get请求适合从服务器端获取数据
  - post适合向服务器端传送数据
  - get是安全的，绝对安全，只是为了从服务器获取数据
  - post请求是危险的，因为post请求向服务器提交数据，如果这些数据通过后门的方式进入到服务器中，服务器是很危险的，另外post请求是为了提交数据，所以一般情况下拦截请求的时候，大部分会选择拦截post请求
  - get请求支持缓存,post请求不支持缓存   
  - 任何一个get请求最终响应结果，都会被浏览器缓存，一个get请求的路径，对应一个资源
  - 发送get请求，现在浏览器缓存中找，找不到就去服务器中获取                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      

  GET请求和POST请求如何选择，什么时候用GET请求，什么时候用POST请求？

  怎么向服务器发送POST请求？（只要form表单中method值为POST时，GET默认情况）

  直接在浏览器输入URL的shiGET,超链接是GET

​	怎样避免get走缓存？只要每一次get请求的路径不同即可

### 9.1模板方法设计模式

模板方法定义核心算法骨架，具体实现步骤可以延迟到子类当中其实现，核心算法一方面得到保护，不能被改变，另一方面算法得到了重复使用

模板类通常是抽象类。模板方法通常final修饰

# 10.HTTP Servlet

- Httpservlet类是专门为HTTP协议准备的，比GenericServlet更加适合HTTP协议的开发

- HttpServletRequest中封装了什么信息？

  HTTPServletRequest:简称request对象

  HTTPServletRquest中封装了请求协议的全部内容

  Tomcat服务器将请求协议中的全部数据解析出来，然后将这些数据全部封装到request对象中了

  也就是说，只要面向HTTPServletRequest,就能获取请求协议中的数据

  

- HttpservletResponse是专门来响应HTTP协议的

- HttpServlet源码分析

  ```java
  public class HelloServlet extends HttpServlet{
      //用户第一次请求，创建Helloservlet对象，执行无参构造方法
      public HelloServlet(){
          
      }
  }
  //自身没有initial方法，所以调用父类的init方法
  public abstract class GenericServlet implements Servlet, ServletConfig, Serializable{
      //用户第一次请求的时候，HelloServlet对象第一次被创建之后，这个init方法会执行
      public void init(ServletConfig config) throws ServletException {
          this.config = config;
          this.init();//调用无参的init
      }
     public void init() throws ServletException {
      }
  }
  public abstract class HttpServlet extends GenericServlet{
  public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
  if (req instanceof HttpServletRequest && res instanceof HttpServletResponse) {				//向下转型带有http的
              HttpServletRequest request = (HttpServletRequest)req;
              HttpServletResponse response = (HttpServletResponse)res;
              //调用重载的service
              this.service(request, response);
          } else {
              throw new ServletException("non-HTTP request or response");
          }
      }
   protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
          String method = req.getMethod();//返回请求方式
          long lastModified;
          if (method.equals("GET")) {
              lastModified = this.getLastModified(req);
              if (lastModified == -1L) {
                  this.doGet(req, resp);
              } else {
                  long ifModifiedSince = req.getDateHeader("If-Modified-Since");
                  if (ifModifiedSince < lastModified) {
                      this.maybeSetLastModified(resp, lastModified);
                      this.doGet(req, resp);
                  } else {
                      resp.setStatus(304);
                  }
              }
          } else if (method.equals("HEAD")) {
              lastModified = this.getLastModified(req);
              this.maybeSetLastModified(resp, lastModified);
              this.doHead(req, resp);
          } else if (method.equals("POST")) {
              this.doPost(req, resp);
          } else if (method.equals("PUT")) {
              this.doPut(req, resp);
          } else if (method.equals("DELETE")) {
              this.doDelete(req, resp);
          } else if (method.equals("OPTIONS")) {
              this.doOptions(req, resp);
          } else if (method.equals("TRACE")) {
              this.doTrace(req, resp);
          } else {
              String errMsg = lStrings.getString("http.method_not_implemented");
              Object[] errArgs = new Object[]{method};
              errMsg = MessageFormat.format(errMsg, errArgs);
              resp.sendError(501, errMsg);
          }
  
      }
  }
  //action 中项目名 /项目名/路径，项目名在服务器中找
  ```

  - HelloServlet直接继承HttpServlet，直接重写service(),享受不到405错误，享受不到http协议抓书东西

## web站点的欢迎页面

在webapp内部的web.xml文件中（配置属于局部）

在CATALINA_HOME/conf/web.xml文件中进行配置（配置属于全局）

tomcat全局欢迎页面是:index.html index.jsp

局部优先原则

欢迎页可以是servlet吗？（可以，欢迎是一个资源，那么可以是静态，可以是动态，servlet属于动态）

```java
public class WelComServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
//        request.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        out.println("<h1>welcome to servlet</h1>");
    }
}
```

在xml文件中配置

```xml
<welcome-file-list>
        <welcome-file>welcom</welcome-file>
    </welcome-file-list>
    <servlet>
        <servlet-name>welcomservlet</servlet-name>
        <servlet-class>com.syztu.javaweb.servlet.servlet007.WelComServlet</servlet-class>
    </servlet>
    <servlet-mapping>
        <servlet-name>welcomservlet</servlet-name>
        <url-pattern>/welcom</url-pattern>
    </servlet-mapping>
```

# 10.1web-INF

- 在web-INF下新建html文件
- 打开浏览器404
- 在web-INF下资源是受保护的，静态资源一定要放在此目录之外

# 10.2HttpServletRequest接口详解

HttpServletRequest是接口，全限定名:jakarta.servlet.HttpServletRequest

HttpServletRequest接口是Servlet规范中的一员

HttpServletRequest接口的父接口：ServletRequest

```java
public interface HttpServletRequest extends ServletRequest{}
```

- HttpServletRequest实现类谁写的，谁创建的

  通过测试org.apache.catalina.connector.RequestFacade实现了HttpServletRequest接口

  

```java
public class RequestFacade implements HttpServletRequest{}
```

tomcat服务器实现了HttpServletRequest,而对于javaweb程序元来说，我们只关心面向接口编程，接口中的方法，方法完成的功能

HttpServletRequest对象是tomcat服务器负责创建的，封装了Http请求协议

实际上用户发送请求时，遵循了HTTP协议，发送的是Http的请求协议，tomcat服务器将协议中的信息以及数据全部解析出来，然后tomcat服务器把这些信息封装到HttpServletRequest对象当中，传给了Java操作者

request 和response生命周期？只在当前请求中有效

常用方法都哪些？

- 前端怎么获取浏览器用户提交的数据？

```java
//HttpServletRequest
String getParameter()
Map<String,String[]> getParmeterMap()
//如果用Map存，key重复的时候value覆盖，可以Map<String,String[]>
Enumeration getParameterNames()
String[] getParmetervalues()//复选框
String getParameter()//用的最多
//以上4个方法和用户提交数据有关系
```

前端form表单提交的数据，怎么存储呢？

前端表单提交数据的时候，以字符串提交的

- 应用域对象（ServletContext）
- 什么情况下向应用域中绑定数据?(共享、数据量小、修改操作少)
- 缓存技术是提高系统性能的重要手段

request又称为请求域对象

- 请求域对象比应用域对象范围小，生命周期短
- 请求域只在一次请求中有效

```java
void setAttribute(String name,Object obj)//向域中绑定数据
void getAttribute(String name)//从域中根据name获取数据
void removeAttribute(String name)//将域中绑定数据移除
```

- 请求域和应用域选取原则

  尽量使用小的域对象，因为小的域对象占用的资源少

  一个请求域

- Servlet 对象不能来nwe ,因为new出来的Servlet对象生命周期不受Tomcat服务器的管理，可以只用资源跳转
  - 转发
  - 转发是一次请求

```java
//第一步，获取请求转发对象
RequestDispatcher dispatcher=request.getRequestDispacher("/b");
//调用forward
dispatcher.forward(req,resp)
```

```
String username=request.getParameter("username");
Object obj=request.getAttribute("name");
//第一个方法获取用户在浏览器上的数据
//第二个方法获取请求域中绑定的数据
//获取客户端IP
getRemoteAddr()
```

```java
//get请求乱码解决
//修改CATALINA_HOME/conf/server.xml配置文件
<Connector URIEncoding="UTF-8">
//注意：从tomcat8之后uriencoding默认utf-8
//获取应用的根路径
//获取servletpath
String servletPath = req.getServletPath();
System.out.println(servletPath);
```

```java
//部门的增删改//add.html  edit.html  detail.html  index.html list.html
```

- 实现功能：后端向前端写，按照程序执行的流程来写

- 建设从前端开始，一定是用户点击按钮的时候开始

- 先修改前端的超链接<!--    前端超链接发送请求的时候，请求路径以"/"开始，并且要带项目名  /项目名/-->

- 编写web.xml

- 技巧

  ```java
   out.print("<a href='"+contextPath+"/dept/detail?deptno="+deptno+"'>详情</a>");
  ```

  重点：提交格式

  解决404问题

  web.xml

  ```javascript
  javascript:void(0)//不跳转，禁用，保留超链接，点击不跳转
  ```

# 10.3在一个web应用中怎样完成资源的跳转

- 两种方式

- 方式一:转发

  ```Java
  
  ```

- 转发与重定向的区别

  ```java
  //代码上的区别转发
  RequestDispatcher dispatcher=request.getRequestDispatcher("/dept/list").forward(req,resp)
  // http://localhost:8888/javaSE_war_exploded/a(转发路径)
  //重定向
  resp.sendRedirect("/项目名/b");
  //response把路径（servlet10/b）重新响应给浏览器，浏览器自发向服务器发全新的请求(http://localhost:8888/servlet10/b),浏览器一共发送2次请求
  //第一次请求：http://localhost:8888/servlet10/a
  //第二次请求:http://localhost:8888/servlet10/b
  //重定向会导致地址栏上的地址发生改变
  
  ```

- 重定向

  ```Java
  //浏览器发请求，请求路径要添加项目名
  resp.sendRedirect(req.getContextPath()+"/b");
  ```

- 转发与重定向的本质区别

  - 转发：是由web服务器来控制的
  - 重定向:是浏览器来完成的

- 什么时候用重定向？什么时候用转发？

  如果在上一个servlet对象当中向request域中绑定了数据，希望从下一个servlet当中把request域里面的数据取出来，使用转发机制

- 剩下所有请求均使用重定向

- 转发会存在浏览器的刷新问题

  前端提交数据后端接受数据,若使用重定向,刷新一次页面就会往数据库中添加数据

# 10.4servlet注解，简化配置

一些需要变化的信息，配置到web.xml中。一般都是注解+配置文件的开发模式

一些不会经常变化的修改的配置建议使用注解，一些可能会被修改的建议写到配置文件中

- 第一个注解

  ```Java
  /*@WebServlet(name="hello")
  属性:name 等同于<servle-tname>
  属性:loadOnStartup 用来指定服务器启动阶段是否加载该Servlet,等同于<load-on-startup>1<load-on-startup>
  urlPatterns = {"/hello1","/hello2","hello3"}用来指定servlet的映射路径，可以指定多个字符串
  web.xml文件中<load-on-startup>1<load-on-startup>表示服务器启动时，创建servlet对象*/
  ```

  ```Java
  
  @WebServlet(name="hello",urlPatterns = {"/hello1","/hello2","/hello3"},initParams =
          {@WebInitParam(name="username",value = "root"),@WebInitParam(name="password",value = "1232")})
  public class HelloServlet extends HttpServlet {
  
      public HelloServlet(){
          System.out.println("无参构造方法执行");
      }
      @Override
      protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      response.setContentType("text/html;charset=utf-8");
          PrintWriter out = response.getWriter();
  
          String servletName = getServletName();
          out.print(servletName);
          //获取servlet path
          String servletPath = request.getServletPath();
          out.print(servletPath);
          //获取初始化参数
          Enumeration<String> initParameterNames = getInitParameterNames();
          while (initParameterNames.hasMoreElements()){
              String name = initParameterNames.nextElement();
              String initParameter = getInitParameter(name);
              out.print(initParameter);
          }
      }
      ////@WebServlet(urlPatterns = "/welcome")
  	//@WebServlet(value = "/welcome2")效果一样
  ```

  - 不是所有属性都要写，需要什么用什么

通过反射获取注解中的值

```Java
package com.zyStu.javaweb.servlet;

import javax.servlet.annotation.WebServlet;

public class ReflectionAnnoation {
    public static void main(String[] args) throws ClassNotFoundException {
      Class<?> WelcomClass=  Class.forName("com.zyStu.javaweb.servlet.WelComeServlet");
      //获取类上面的注解对象
        //先判断有没有注解对象
//        boolean annotationPresent = WelcomClass.isAnnotationPresent(WebServlet.class);
//        System.out.println(annotationPresent);
        if( WelcomClass.isAnnotationPresent(WebServlet.class)){
            //获取类上面的注解对象
            WebServlet annotation = WelcomClass.getAnnotation(WebServlet.class);
            //获取注解的value属性值
            String[] value = annotation.value();
            for (String s : value) {
                System.out.println(s);
            }
        }
    }
}

```

一个单表的CRUD，使用了6个Servlet，如果一个复杂的业务系统，这种开发方式，显然会导致类爆炸（类的数量大）

怎么解决这个问题呢？可以使用模板方法设计模式

实际上访问index.jsp,底层执行的时index jsp.class这个程序，index.jsp被tomcat防疫生成index jsp.java文件，然后tomcat将index jsp.Java编译生成index jsp.class文件

访问index.jsp,实际上执行的时index jsp.class 中的方法 

jsp实际上就是一个Servlet

- jsp和servlet有什么区别吗?

  servlet职责是什么?（收集数据）

  JSP的职责是什么?（展示数据）

- index.jsp访问的时候，会自动翻译生成index _jsp.java,会自动编译生成index jsp.class ，那么index.jsp就是一个类
- index.jsp 类继承HttpJspBase,而HttpJspBase这个类继承的是HttpServlet,所以index.jsp类就是一个Servlet类
- jsp的生命周期和Servlet完全相同
- jsp和servlet都是单例的，（假单例）
- jsp文件第一次访问慢（Java->class->调用init）需要翻译生成Java文件-》class文件

- Servlet是JavaEE的13个子规范之一，那么JSP也是javaEE的13个子规范之一。

- JSP是一套规范，所有的web容器/web服务器都是遵循这套规范的，都是按照这套规范进行翻译的

- 每一个web容器/web服务器都会内置一个JSP翻译引擎

- 为什么要尽量少用<%!%>JSP写法？

  因为在Service外面写静态变量和实例变量，都会存在线程安全问题，jsp就是servlet,servlet是单例的，多线程并发的环境下，静态变量和实例变量一旦有修改操作，必然存在线程安全问题

- JSP文件扩展名是可以配置的，tomcat/conf/wex.xml

- ```java
  out.write("shi");输出到浏览器
  //直接输出字符串
  <%=%> =后面写要输出的内容会被翻译到service中输出内容到浏览器上
  ```

- javabean：符合某种规范的Java类，实体类，负责数据的封装，具有很强的通用性

  有无参构造，属性私有化，对外公开set、get方法，实现Serializable接口，重写toString......

## 10.5关于B/S结构系统的会话机制（Session）

+ # 什么是会话？

  用户打开浏览器操作，然后终将关闭浏览器，这个整个过程，叫做一次会话

- 一次会话对应N次请求

- 在Java的servlet规范中，session对应的类名：HttpSession(jarkata.servlet.http.HttpSession)

- session机制属于B/S结构的一部分，如果使用php语言开发web项目，同样也是这种机制，session实际上是一种规范，然后不同的语言对这种会话机制都有实现

- session对象主要作用是:保存会话状态

- 为什么需要session对象来保存会话状态呢？

   因为HTTP协议是无状态协议

  什么是无状态呢？请求的时候，B/S是连接的，请求结束之后，连接就断了。为什么要这么做？无状态协议，减小服务器压力

  只要B/S断开了，那么关闭浏览器这个动作，，服务器知道吗？

- 张三打开浏览器A,李四打开浏览器B，访问服务器后,在服务器端生成:
  - 张三专属的session对象
  - 李四专属的session对象

- resquest对象为什么不能保存？request对象生命周期短

- 为什么不使用servletContext保存会话?域太大

- 思考：session实现原理

  在web服务器有一个session列表，类似于map集合{session列表Map(<key(session) value(session对象)>)}

  用户发送第一次请求时，服务器会创建新的session对象，同时给session对象生成一个id，然后web服务器会将session的id发送给浏览器，然后浏览器将sessionid保存在浏览器的缓存中，用户发送第二次请求中，会自动将缓存中的sessionid自动发送给服务器，服务器根据id查到对象

  ```Java
  //获取session
  HttpSession session=request.getsession();
  //从服务器中获取对应的session对象，如果没有，则创建
  HttpSession session=request.getSession(false);
  //如果获取不到，则不会新建，返回null
  ```

- session列表Map(<key(session) value(session对象)>)

- 为啥关闭浏览器，会话结束

  关闭浏览器之后，浏览器中保存的session消失，下次重新打开浏览器之后，浏览器缓存中没有这个sessionid，自然找不到对应的session对象

  session对象销毁是超时销毁，还可以手动销毁

- session配置

  ```xml
  <session-config>
          <session-timeout>30</session-timeout>
      </session-config>
  //30分钟没人再次访问，销毁
  ```

- cookie禁用:服务器正常发送cookie给浏览器，但是浏览器不要了，那么cookie禁用，sessionid能找到吗?(导致每次发送请求都是新的session)  那么底层session销毁了吗？没有，在等待超时销毁，默认30分钟，解决方式:

  使用URL重写机制:在URL后面加;+jsessionid=session的编号,URL重写机制提高开发成本，所以大部分网站都是这样设计的，禁用cookie，就别用

  ```
  //访问jsp页面，会生成session对象
  //关闭的方法
  <%@page session="false"%>
  ```

#  10.6cookie 

- 对于session关联的cookie来说，这个cookie是被浏览器保存运行内存当中，只要浏览器不关闭，用户再次发送请求的时候，会自动将内存中的cookie发送个Cookie:JSESSIONID=14343455sdf8weww0B8;

- cookie怎么生成?保存在什么地方?作用？浏览器什么时候发送cookie?

- cookie保存在浏览器客户端上，可以保存在运行内存中（浏览器关闭消失），也可以保存在硬盘文件上（永久保存）

- cookie有什么用?保存会话的状态

- session是将会话状态保存在服务器端上

- 为啥要有cookie和session机制?因为HTTP协议是无状态，无连接的协议

- Java程序怎么把cookie发送给浏览器呢？response.addCookie(cookie)

  ```java
   cookie.setMaxAge();//设置cookie有效时间 ：单位秒
  //不设置的话，默认保存在浏览器运行内存中，关闭后就没了
  //只要设置的时间大于0，就会保存到硬盘文件中
  //等于0删除重名cookie的，只要应用，删除浏览器上的重名cookie
  //小于0,表示该cookie不会被存储，放在浏览器运行内存中，和不调用setMaxAge()是同一个效果
  //默认情况下，没有设置path的时候，cookie关联的路径是什么?
  Cookie[] cookies = req.getCookies();//如果浏览器没有提交cookie，返回null
  cookies.getName()//获取cookie的名字
  cookies.getValue()//获取cookie的值
  ```

- 假设现在发送的请求路径是"[localhost:8888/Servlet13_war_exploded/cookie/generate](http://localhost:8888/Servlet13_war_exploded/cookie/generate)"生成的cookie，如果cookie没有设置path，默认的path是什么?"localhost:8888/Servlet13_war_exploded/cookie" 以及子路径。
- 手动设置cookie的path cookie.setPath("/servlet13");只要是servlet下的请求路径，都会提交给服务器

- 126邮箱十天免登录功能

  - 实现登录功能

    - 登录成功

      跳转部门页面

    - 登录失败

      登录失败页面

  - 修改前端页面，在登录页面给一个复选框，提示：十天内免登录

- 用户访问网页有两个走向:要么跳转到部门列表页面，要么到登录页面 

- JSP九大内置对象:pageContext request session application response out config page exception

- JSP的指令

  - 指令jsp翻译引擎如何工作
  - 指令包括那些呢?
    - include:包含指令，完成静态包含
    - taglib:引入标签库的指令JSTL
    - page:目前重点

  - ```jsp
    <%@page errorPage="error.jsp"%>//用来指定出错之后的跳转位置
    //在错误页面可以启用JSP的九大内置对象:exception
    ```

- ```jsp
  
  //error页面输出异常信息到控制台
  <%--
    Created by IntelliJ IDEA.
    User: ZY
    Date: 2022/8/27
    Time: 20:50
    To change this template use File | Settings | File Templates.
  --%>
  <%@ page contentType="text/html;charset=UTF-8" language="java" %>
  <%@page isErrorPage="true" %>
  <html>
  <head>
      <title></title>
  </head>
  <body>
  <h1>网络繁忙</h1>>
  <%
      //打印异常信息输出到控制台
      exception.printStackTrace();
  %>
  </body>
  </html>
  
  ```

- ```java
  //十天免登录
  					Cookie cookie = new Cookie("username",username);
                      Cookie cookie1 = new Cookie("password",password);//真是情况加密
                      cookie.setMaxAge(60*60*24*10);
                      cookie1.setMaxAge(60*60*24*10);
                      //设置cookie的path,只要访问这个应用，浏览器就一定携带这两个cookie
                      cookie.setPath(request.getContextPath());
                      cookie1.setPath(request.getContextPath());
                      response.addCookie(cookie);
                      response.addCookie(cookie1);
  ```
  
  
  
- JSP的九大内置对象

# 10.7EL表达式(Expression Language)

- EL表达式可以代替jsp中的Java代码，让jsp文件中的程序看起来更加整洁，美观
- EL表达式出现在jsp中，主要是从某个作用域中取数据，将其转换成字符串，输出到浏览器，三大功效
  - 从某个域中取数据
  - 将取出的数据输转成字符串
  - 将字符串输出到浏览器

- EL表达式主要是数据展示，所以null实在浏览器显示不出来
- EL表达式最终执行的是Java程序，被jsp翻译

```jsp
<%@page contentType="text/html;charset=UTF-8" %>

<%
request.setAttribute("username","request");
  session.setAttribute("username","session");
  pageContext.setAttribute("username","pageContext");
  application.setAttribute("username","application");
%>

<%--EL表达式--%>
${username}
//访问顺序从小范围到大范围，可手动指定
${requestScope.username}
${pageContext.username}
${session.username}
${appplication.username}
//page指令中有一个属性，可忽略EL表达式
//isELIgnored="true"
//忽略一个  
\${name}
```

- EL表达式取数据的时候
  - 1：.
  - 2: [] name中有特殊字符,注意取的时候加""

- EL 表达式没有request隐式对象
- EL表达式中有一个隐式对象，pageContext
- EL表达式中的pageContext和JSP中的九大内置对象pageContext是同一个对象

```
<%=pageContext.getRequest()%>等于
${pageContext.request}
${pageContext.request.contextPath}//获取应用的根
```

- EL表达式其他隐式对象

  ```
  爱好:${param.aihao}<br>传递多个值，只能拿到第一个
  爱好:${paramValues.aihao[2]}//能获取所有的，是一个数组
  ```

- EL表达式中"+"运算符只能求和运算，不会进行字符串拼接操作,例如拼接"abc"会报错

empty 判断是否为空 ${empty param.username}为空true 否则false

# 11.JSTL标签库

- 什么是jstl标签库？
  - Java Standard Tag Lib(Java标准的标签库)
  - JSTL标签库通常结合EL表达式一起使用，目的是让jsp中的Java代码消失

- 使用jstl标签库步骤：
  - 引入jstl标签库的jar包
    - Jakarta.servlet.jsp.jstl-2.0.0.jar
    - taglibs.standard-imp-1.2.5.jar
    - taglibs.standard-spec-1.2.5.jar

- 在web-INF下新建lib,将jar包拷贝到目录中,然后添加到库

- 为什么jsp文件中这样写

  ```jsp
  <%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
  ```

- 原因

```xml
  <tag>
    <description>
        Catches any Throwable that occurs in its body and optionally
        exposes it.
    </description>
    <name>catch</name>//标签的名字
    <tag-class>org.apache.taglibs.standard.tag.common.core.CatchTag</tag-class>//标签对应的Java类
    <body-content>JSP</body-content>//标签体中可以出现的内容
    <attribute>
        <description>
Name of the exported scoped variable for the
exception thrown from a nested action. The type of the
scoped variable is the type of the exception thrown.
        </description>
        <name>var</name>
        <required>false</required>//该属性不是必须的
        <rtexprvalue>false</rtexprvalue>//说明该属性是否支持EL表达式
    </attribute>
  </tag>
```

- jstl核心标签库core

- ```jsp
  <c:forEach items="${stuList}" var="s"><br>
      name:${s.name}<br>
      age:${s.age}
  </c:forEach>
  
  <c:forEach items="${stuList}" var="s" varStatus="stuStatus"><br>
      id:${stuStatus.count} //编号1开始
      name:${s.name}
      age:${s.age}<br>
  </c:forEach><br>
  <c:forEach var="i" begin="1" end="10" step="2">
      ${i}
  </c:forEach>
  ------------------------------------------------------------------------------------  <c:choose>
      <c:when test="${param.age<18}">
          青少年
      </c:when>
      <c:when test="${param.age<35}">
          青年
      </c:when>
      <c:when test="${param.age<55}">
          中年
      </c:when>
      <c:when test="${param.age<90}">
          老年
      </c:when>
      <c:otherwise>
          入土了
      </c:otherwise>
  </c:choose>
  //类似域if/else
    
  ```

  ```html
  <base href="http://localhost:8888/oa/">
  //在当前页面中,凡是路径没有以"/"开始的,都会自动将base中的路径添加到这些路径之前
  <base href="${pageContext.request.scheme}://${pageContext.request.serverName}:${pageContext.request.serverPort}/${pageContex
  ```

  需求：假如有个订单，那么就必须要登录，与用户的servlet登录一样（过滤器）

# 12.过滤器(Filter)

- Filter是什么？有什么用？

- Filter是过滤器，Filter可以在Servlet这个目标程序执行之前添加代码，也可以在目标Servlet执行之后添加代码，之前之后都可以添加过滤规则

- 一般情况下，都是在过滤器中编写公共代码

- 一个过滤器怎么写?

  - 1:编写Java类实现jarkarta.servlet.Filter,并且实现这个接口的所有方法

    ```java
    init()方法:在Filter对象第一次被创建之后调用，并且值调用一次
    doFilter()方法:只要用户发送一次请求，则执行，发几次执行几次
    destroy()方法:在Filter对象被释放/销毁之前调用,并且只调用一次
    ```

  - 在web.xml文件中配置

    ```xml
    <filter>
        <filter-name>filter1</filter-name>
        <filter-class>com.zyStu.javaweb.servlet.Filter1</filter-class>
    </filter>
    <filter-mapping>
        <filter-name>filter1</filter-name>
        <url-pattern>/abc</url-pattern>
    </filter-mapping>
    ----------------------------------------------------------------------------
    <url-pattern>*.do</url-pattern>//模糊匹配之扩展匹配
    ```

  - 注意：Servlet对象在默认情况下，是不会新建对象的

  - Filter默认情况下，在服务器启动时会新建对象，Servlet是单例的，Filter也是单例的（单实例）

  - 目标servlet是否执行取决于2个条件：1在过滤器中是否编写了chain.doFilter(request,response)2请求路径是否和servlet路径一致

  - chain.doFilter(req,res):执行下一个过滤器，如果下面没有过滤器了，执行最终的servlet

  - Filter优先级大于Servlet

  - ```xml
    <filter-mapping> //决定filter执行顺序
    ```

- 使用WebFilter的时候，Filter的执行顺序时怎样的?

  执行顺序是:比较Filter这个类名，FilterA和FilterB则先执行FilterA

- Filter 生命周期跟Servlet一样，唯一区别，服务器启动时就创建对象
- 过滤器最大的优点:在程序编译阶段不会确定调用顺序,因为Filter的调用顺序是配置web.xml文件中的，只要修改FilterMapping的顺序，就可以调整执行顺序，执行顺序是在程序运行阶段动态组合的，这种设计模式就是责任链
- 最大核心思想:在程序运行阶段动态组合，程序执行顺序

# 13.监听器

- 什么是监听器

  监听器是servlet规范中的一员，就像filter一样

  在servlet中，所有的监听器接口都是以"Listener"结尾

- 监听器有什么作用?

  监听器实际上是servlet规范留给我们javaweb的特殊时机

  特殊的时刻想执行这段代码，你需要想到使用对应的监听器

- jakarta.servlet包下:

   ServletContextListener

  ServletContextAttributeListener

  ServletRequestListener

  ServletRequestAttributeListener

- jakart.servlet.http包下:

  HttpSessionLisener

  HttpSessionAttributeLisener

  - 需要WebListener注解进行标注
  - 该监听器监听的是什么?是session域中数据的变化，则执行响应的办法，主要监测点在session域对象

  HttpSessionBindingLisener

  - 该监听器不需要使用注解标注
  - 假设User类实现了该监听器，那么User对象在被放入session的时候触发bind事件,User对象从session中删除的时候，出发unbind事件

  HttpSessionldListener

  - session的id改变的时候，监听器中唯一一个方法就会被调用

  HttpSessionActivationListener

  - 监听session的钝化和活化
  - 钝化:session对象从内存存储到硬盘文件
  - 活化:从硬盘文件把session恢复到内存

- 实现一个监听器的步骤

  实现ServletContextListener

  ```java
  public class MyServletContextListener implements ServletContextListener {
  //实现2个方法
      @Override
      public void contextInitialized(ServletContextEvent servletContextEvent) {
          //servletContext被创建的时候调用
      }
  
      @Override
      public void contextDestroyed(ServletContextEvent servletContextEvent) {
  		//servletContext被销毁的时候调用
      }
  }
  ```

​				第二步:配置文件

```xml
<listener>
    <listener-class>com.zyStu.javaListener.servlet.MyServletContextListener</listener-class>
</listener>
//或者
-------------------------------------------------------------------------------------------
也可以加注解@WebListener
```

- 所有监听器中的方法不是javaweb CXY来调用，都是服务器来负责的，什么时候调用？

  当某个特殊事件（时机到了）发生之后，被web服务器自动调用

- 编写功能，记录网站实时在线用户个数:可以通过服务器端有没有分配session对象，因为一个session代表了一个用户，有一个session代表一个用户(HttpSessionLisener)
- 只统计登录用户在线数量:(HttpSessionBindingLisener)
- 用户登录的标志是什么?session曾经存储过User类型的对象，那么这个时候可以让User类型的对象实现HttpSessionBindingLisener监听器，只要User对象存储到session域中，然后将count++存储到ServletContext对象中，页面展示在线人数即可

- ServletRequestListener

  ```java
  public class MyServletRequestListener implements ServletRequestListener {
      @Override
      public void requestDestroyed(ServletRequestEvent servletRequestEvent) {
          
      }
  
      @Override
      public void requestInitialized(ServletRequestEvent servletRequestEvent) {
  
      }
  }
  ```

- HttpSessionListener

  ```java
  public class MySessionListener implements HttpSessionListener {
      @Override
      public void sessionCreated(HttpSessionEvent httpSessionEvent) {
          //访问jsp会默认创建session
      }
  
      @Override
      public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
  
      }
  }
  ```

- HttpSessionAttributeLitsener

  ```java
  public class MyHttpSessionAttributeLitsener implements HttpSessionAttributeListener {
      @Override
      public void attributeAdded(HttpSessionBindingEvent httpSessionBindingEvent) {
          //向session域存储数据，被web服务器调用
      }
  
      @Override
      public void attributeRemoved(HttpSessionBindingEvent httpSessionBindingEvent) {
  
      }
  
      @Override
      public void attributeReplaced(HttpSessionBindingEvent httpSessionBindingEvent) {
          //session域中某个数据被替换的时候触发
      }
  }
  ```

- HttpSessionBindingLisener

  ```java
  
    @Override
      public void valueBound(HttpSessionBindingEvent httpSessionBindingEvent) {
          //绑定数据
          //需要向session域中绑定数据的对象实现这个接口，当session.setAttribute触发时，自动调用			这个方法
          //加入让user实现这个接口，当user被加到(绑定)session中的时候，才会出发这个方法
          //通过httpSessionBindingEvent.getValue()获取存到session中的值
      }
  
      @Override
      public void valueUnbound(HttpSessionBindingEvent httpSessionBindingEvent) {
          //解绑数据
      }
  ```

  
